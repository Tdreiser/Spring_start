create view comments_into_message(count, message_id) as
SELECT (SELECT COALESCE(count(c.*), 0::bigint) AS count) AS count,
       m.id                                              AS message_id
FROM messages m
         LEFT JOIN comments c ON m.id = c.message_id
GROUP BY m.id;

alter table comments_into_message
    owner to postgres;

