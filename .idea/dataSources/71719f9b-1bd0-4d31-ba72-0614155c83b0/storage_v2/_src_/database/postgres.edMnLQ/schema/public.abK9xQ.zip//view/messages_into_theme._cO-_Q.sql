create view messages_into_theme(count, theme_id) as
SELECT (SELECT COALESCE(count(m.*), 0::bigint) AS count) AS count,
       t.id                                              AS theme_id
FROM themes t
         LEFT JOIN messages m ON m.theme_id = t.id
GROUP BY t.id;

alter table messages_into_theme
    owner to postgres;

