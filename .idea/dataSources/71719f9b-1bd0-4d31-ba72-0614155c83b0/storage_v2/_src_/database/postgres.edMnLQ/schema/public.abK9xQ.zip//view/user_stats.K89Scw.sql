create view user_stats(id, likes, dislikes) as
SELECT users.id,
       ((SELECT COALESCE(sum(t.likes), 0::bigint) AS "coalesce")) +
       ((SELECT COALESCE(sum(m.likes), 0::bigint) AS "coalesce"))    AS likes,
       ((SELECT COALESCE(sum(t.dislikes), 0::bigint) AS "coalesce")) +
       ((SELECT COALESCE(sum(m.dislikes), 0::bigint) AS "coalesce")) AS dislikes
FROM users
         LEFT JOIN messages m ON users.id = m.user_id
         LEFT JOIN themes t ON users.id = t.user_id
GROUP BY users.id;

alter table user_stats
    owner to postgres;

